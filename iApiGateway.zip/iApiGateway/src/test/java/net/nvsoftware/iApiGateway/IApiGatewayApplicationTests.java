package net.nvsoftware.iApiGateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
