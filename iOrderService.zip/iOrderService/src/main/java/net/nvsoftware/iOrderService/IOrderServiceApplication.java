package net.nvsoftware.iOrderService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IOrderServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(IOrderServiceApplication.class, args);
	}

}
