package net.nvsoftware.iProductService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IProductServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(IProductServiceApplication.class, args);
	}

}
